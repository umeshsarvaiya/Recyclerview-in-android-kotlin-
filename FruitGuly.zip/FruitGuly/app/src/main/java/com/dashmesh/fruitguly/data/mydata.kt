package com.dashmesh.cart.data

data class mydata(
    val d: D
)