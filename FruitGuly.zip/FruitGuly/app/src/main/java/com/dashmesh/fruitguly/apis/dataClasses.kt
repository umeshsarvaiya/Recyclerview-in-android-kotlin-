package com.dashmesh.fruitguly.apis

data class LoginRequestObj(
    val Username:String,
    val Password:String
)