package com.dashmesh.myorder.APIWorker

import com.dashmesh.fruitguly.apis.LoginRequestObj
import com.dashmesh.myorder.*
import com.google.gson.annotations.SerializedName
import org.json.JSONObject
import retrofit2.Call
import retrofit2.http.*


//phone 1 3 account/

public interface API {

    @Headers("Content-Type:application/json")
    @POST("doLogin")
    fun login(
        @Body
        obj:LoginRequestObj
    ): Call<JSONObject>


}