package com.dashmesh.cart.data

data class Response(
    val FieldValue: String,
    val Message: String,
    val Status: String,
    val __type: String
)