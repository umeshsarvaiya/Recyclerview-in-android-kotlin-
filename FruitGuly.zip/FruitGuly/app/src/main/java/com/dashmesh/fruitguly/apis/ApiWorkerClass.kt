package com.dashmesh.myorder.APIWorker

import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import retrofit2.converter.gson.GsonConverterFactory
import java.security.KeyManagementException
import java.util.concurrent.TimeUnit

object ApiWorkerClass {

    private var mclient:OkHttpClient?=null

    private var gsnConverterFactory: GsonConverterFactory?=null

    val mytempclient:OkHttpClient
        @Throws(NoClassDefFoundError::class,KeyManagementException::class)
        get(){
            if(mclient ==null){
                var httpbuilder=OkHttpClient.Builder()
                httpbuilder
                    .connectTimeout(30,TimeUnit.SECONDS)
                    .readTimeout(30,TimeUnit.SECONDS)
                mclient =httpbuilder.build()
            }
            return mclient!!
        }

    val mygsfactory:GsonConverterFactory
        get(){
            if(gsnConverterFactory ==null){
                gsnConverterFactory =GsonConverterFactory
                    .create(
                            GsonBuilder()
                            .setLenient()
                            .disableHtmlEscaping()
                            .create())
            }

            return gsnConverterFactory!!
        }
}