package com.dashmesh.cart.data

data class D(
    val List: List<Fruit>,
    val Response: Response,
    val __type: String
)