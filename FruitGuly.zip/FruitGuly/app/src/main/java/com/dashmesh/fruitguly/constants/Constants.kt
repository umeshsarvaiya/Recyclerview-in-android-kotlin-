package com.dashmesh.fruitguly.constants

class Constants {
    companion object{
        var baseurl="http://dss1.dashmeshsoftwaresolutions.in/apricote/service.svc/"
    }
}