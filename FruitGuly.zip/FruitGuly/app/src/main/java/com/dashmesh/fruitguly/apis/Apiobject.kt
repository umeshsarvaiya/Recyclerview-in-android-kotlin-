package com.dashmesh.myorder.APIWorker

import com.dashmesh.fruitguly.constants.Constants

import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory

object Apiobject{

    fun doLogin()= Retrofit.Builder()
        .baseUrl(Constants.baseurl)
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .addConverterFactory(ApiWorkerClass.mygsfactory)
        .client(ApiWorkerClass.mytempclient)
        .build()
        .create(API::class.java)!!


    fun doRegister()= Retrofit.Builder()
        .baseUrl(Constants.baseurl)
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .addConverterFactory(ApiWorkerClass.mygsfactory)
        .client(ApiWorkerClass.mytempclient)
        .build()
        .create(API::class.java)!!

    fun otherFunction()=Retrofit.Builder()
        .baseUrl(Constants.baseurl)
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .addConverterFactory(ApiWorkerClass.mygsfactory)
        .client(ApiWorkerClass.mytempclient)
        .build()
        .create(API::class.java)!!


    fun subscribeFunction()=Retrofit.Builder()
        .baseUrl(Constants.baseurl)
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .addConverterFactory(ApiWorkerClass.mygsfactory)
        .client(ApiWorkerClass.mytempclient)
        .build()
        .create(API::class.java)!!
}