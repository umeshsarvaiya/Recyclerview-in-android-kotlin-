package com.dashmesh.fruitguly.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.dashmesh.fruitguly.R
import com.dashmesh.fruitguly.apis.LoginRequestObj
import com.dashmesh.myorder.APIWorker.Apiobject
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginFragment:Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view=inflater.inflate(R.layout.loginfragment,container,false)
        val mbutton=view.findViewById<Button>(R.id.btnlogin)
        mbutton.setOnClickListener { callLogin() }
        return view
    }
    fun callLogin(){
        val loginobj=LoginRequestObj("+917817899090","Dharma3009@")
        Apiobject.doLogin().login(loginobj).enqueue(object:Callback<JSONObject>{
            override fun onResponse(call: Call<JSONObject>, response: Response<JSONObject>) {
                if(response.isSuccessful){
                    Log.d("Dharmesh",response.body().toString())
                }
                else {
                    Log.d("Dharmesh",response.message().toString())
                }
            }

            override fun onFailure(call: Call<JSONObject>, t: Throwable) {
                Log.d("Dharmesh",t.message.toString())
            }
        })
    }
}