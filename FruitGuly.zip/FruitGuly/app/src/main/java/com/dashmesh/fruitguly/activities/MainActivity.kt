package com.dashmesh.fruitguly.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.dashmesh.fruitguly.R
import com.dashmesh.fruitguly.fragments.LoginFragment

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var tf=supportFragmentManager.beginTransaction()
        tf.replace(R.id.container,LoginFragment())
        tf.commit()
    }
}